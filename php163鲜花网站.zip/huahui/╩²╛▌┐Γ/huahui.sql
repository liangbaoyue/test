/*
MySQL Data Transfer
Source Host: localhost
Source Database: huahui
Target Host: localhost
Target Database: huahui
Date: 2018/12/29 11:08:32
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for admin
-- ----------------------------
CREATE TABLE `admin` (
  `id` int(4) NOT NULL default '0',
  `name` varchar(13) default NULL,
  `pwd` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for gonggao
-- ----------------------------
CREATE TABLE `gonggao` (
  `id` int(10) NOT NULL auto_increment,
  `title` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `time` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for goods
-- ----------------------------
CREATE TABLE `goods` (
  `id` int(4) NOT NULL auto_increment,
  `mingcheng` varchar(25) default NULL,
  `jianjie` mediumtext,
  `addtime` date default NULL,
  `xinghao` varchar(25) default NULL,
  `tupian` varchar(200) default NULL,
  `shuliang` int(4) default NULL,
  `cishu` int(4) default NULL,
  `tuijian` int(4) default NULL,
  `typeid` int(4) default NULL,
  `huiyuanjia` varchar(25) default NULL,
  `shichangjia` varchar(25) default NULL,
  `pinpai` varchar(25) default NULL,
  `tejia` int(2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for links
-- ----------------------------
CREATE TABLE `links` (
  `id` int(4) NOT NULL auto_increment,
  `linkname` varchar(50) NOT NULL,
  `linkurl` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for liuyan
-- ----------------------------
CREATE TABLE `liuyan` (
  `id` int(4) NOT NULL auto_increment,
  `userid` int(4) default NULL,
  `title` varchar(200) default NULL,
  `content` text,
  `time` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for orders
-- ----------------------------
CREATE TABLE `orders` (
  `id` int(4) NOT NULL auto_increment,
  `dingdanhao` varchar(125) default NULL,
  `spc` varchar(125) default NULL,
  `slc` varchar(125) default NULL,
  `shouhuoren` varchar(25) default NULL,
  `sex` varchar(2) default NULL,
  `dizhi` varchar(125) default NULL,
  `youbian` varchar(10) default NULL,
  `tel` varchar(25) default NULL,
  `email` varchar(25) default NULL,
  `shff` varchar(25) default NULL,
  `zfff` varchar(25) default NULL,
  `leaveword` mediumtext,
  `time` varchar(25) default NULL,
  `xiadanren` varchar(25) default NULL,
  `zt` varchar(50) default NULL,
  `total` varchar(25) default NULL,
  `liuyan` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for pingjia
-- ----------------------------
CREATE TABLE `pingjia` (
  `id` int(4) NOT NULL auto_increment,
  `userid` int(4) default NULL,
  `spid` int(4) default NULL,
  `title` varchar(200) default NULL,
  `content` text,
  `time` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for type
-- ----------------------------
CREATE TABLE `type` (
  `id` int(4) NOT NULL auto_increment,
  `typename` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for user
-- ----------------------------
CREATE TABLE `user` (
  `id` int(4) NOT NULL auto_increment,
  `name` varchar(25) default NULL,
  `pwd` varchar(50) default NULL,
  `dongjie` int(4) default NULL,
  `email` varchar(25) default NULL,
  `sfzh` varchar(25) default NULL,
  `tel` varchar(25) default NULL,
  `qq` varchar(25) default NULL,
  `ip` varchar(25) default NULL,
  `tishi` varchar(50) default NULL,
  `huida` varchar(50) default NULL,
  `dizhi` varchar(100) default NULL,
  `youbian` varchar(25) default NULL,
  `regtime` varchar(25) default NULL,
  `lastlogintime` varchar(25) default NULL,
  `logincishu` int(4) default NULL,
  `truename` varchar(25) default NULL,
  `pwd1` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `admin` VALUES ('0', 'admin', '21232f297a57a5a743894a0e4a801fc3');
INSERT INTO `gonggao` VALUES ('14', '11111111111', '1111', '2015-04-5');
INSERT INTO `gonggao` VALUES ('13', '甜甜情侣屋建设完成', '甜甜情侣屋建设完成甜甜情侣屋建设完成甜甜情侣屋建设完成', '2015-04-5');
INSERT INTO `goods` VALUES ('229', '情人节玫瑰', '情人节玫瑰情人节玫瑰情人节玫瑰情人节玫瑰情人节玫瑰情人节玫瑰情人节玫瑰情人节玫瑰情人节玫瑰情人节玫瑰情人节玫瑰', '2018-12-29', '22', 'admin/upimages/21.jpg', '22', '0', '1', '34', '99', '188', '暂时', '1');
INSERT INTO `goods` VALUES ('230', '情人节玫瑰2', '情人节玫瑰情人节玫瑰情人节玫瑰情人节玫瑰', '2018-12-29', '213', 'admin/upimages/22.jpg', '22', '0', '1', '34', '111', '222', '222', '1');
INSERT INTO `goods` VALUES ('231', '康乃馨', '2222', '2018-12-29', '22', 'admin/upimages/23.jpg', '123', '0', '1', '34', '88', '99', '123', '0');
INSERT INTO `goods` VALUES ('232', '红玫瑰', '222222222', '2018-12-29', '22', 'admin/upimages/24.jpg', '23', '0', '1', '34', '200', '222', '123', '0');
INSERT INTO `links` VALUES ('9', 'd', 'd');
INSERT INTO `links` VALUES ('10', 'dsa', 'asd');
INSERT INTO `type` VALUES ('31', '小礼品');
INSERT INTO `type` VALUES ('34', '鲜花');
INSERT INTO `user` VALUES ('44', 'ztest', 'e10adc3949ba59abbe56e057f20f883e', '0', '11111111@qq.com', '324342342', '324324', '55454', '127.0.0.1', '您的生日', '324', '324324', '', '2015-03-24 ', '2015-03-24 ', '1', '23434', '123456');
INSERT INTO `user` VALUES ('45', 'ztest123', 'e10adc3949ba59abbe56e057f20f883e', '0', '112@qwe.com', '5', '55', '555', '127.0.0.1', '', '', '55', '555', '2011-12-10', '2011-12-10', '1', '5', '123456');
INSERT INTO `user` VALUES ('46', '123456', 'e10adc3949ba59abbe56e057f20f883e', '0', '123456@126.com', '1234141421414', '13664546456', '123456', '127.0.0.1', '', '', '21414', '123456', '2015-01-14', '2015-01-14', '1', '品牌', '123456');
INSERT INTO `user` VALUES ('47', '123321', 'c8837b23ff8aaa8a2dde915473ce0991', '0', '123321@126,com', '3423423423', '123321', '123321', '::1', '', '', '北京市东城', '123321', '2015-03-27', '2015-03-27', '1', '沈智', '123321');
INSERT INTO `user` VALUES ('48', '1234568', 'fe743d8d97aa7dfc6c93ccdc2e749513', '0', '1234568@126.com', '3423423423', '1111111234568', '1234568', '::1', '', '', '北京市东城', '1234568', '2015-04-5', '2015-04-5', '1', '沈智', '1234568');
