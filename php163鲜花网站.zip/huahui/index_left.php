<TABLE border=0 cellPadding=0 cellSpacing=0 width="180">
  <TBODY>

 <TABLE align=center border=0 cellPadding=1 cellSpacing=1
                        width="100%">
<TR>
              <TD width="180" height="35" class="menu_left">��Ʒ����</TD></tr>
        <FORM action=search.php method=post name=form2>

            <TR>
              <TD align=middle>����ؼ��֣�
                  <INPUT class=wenbenkuang name="name" size=30> </TD>
            </TR>

            <TR>
              <TD align=middle height=38>  <input type="hidden" name="jdcz" value="jdcz">
                          <input name="submit" type="submit" class="buttoncss" value="��������">
               </TD>
            </TR>
        </FORM>

      </TABLE>



            <table width=100% cellspacing="0" cellpadding="0" border="0">
			<tr>
          <TD width="180" height="35" class="menu_left">��Ʒ����</TD>
        </tr>
<?php
$sql="select * from type ";
$res=mysql_query($sql);
while($a=mysql_fetch_array($res))
{
?>
              <tr align="center">
                <td height="30" colspan=3  style="CURSOR: hand" onMouseOver="this.bgColor='#FFFFFF';" onMouseOut="this.bgColor='#FFFFFF';"><font color="#FFFFFF"><a href=showfenlei.php?id=<?php echo $a[id]?>><b><font color="#FF6600" size=+1><?php echo $a[typename]?></font></b></a></font></td>
              </tr>

<?php
}
	?>
              <tr>
                <td colspan=3 height=1 background="images/bj_x1.gif" ></td>
              </tr>
            </table>






<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
          <TD width="180" height="35" class="menu_left">��������</TD>
  </tr>
  <?php
   $sql1=mysql_query("select * from goods order by cishu desc",$conn);
             while($paihang=mysql_fetch_array($sql1))
		     {
				 ?>
<tr><td height="24" background="image/dp_bg.gif" class="table-you"  STYLE='PADDING-LEFT: 18px'>
<a href="good_view.php?id=<?php echo $paihang[id];?>"><?php echo $paihang[mingcheng];?></a></td>
</tr>
 <?php
	    }

		?>
</table>