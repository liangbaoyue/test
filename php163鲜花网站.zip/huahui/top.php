<?php
   session_start();
   include("conn.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>��������ϵͳ</title>
<link rel="stylesheet" type="text/css" href="images/css.css">
<style type="text/css">
<!--
.style2 {color: #CC3399}
.style4 {color: #FFFFCC}
-->
</style>
</head>
<script language="javascript">

  function chkinput1(form){
    if(form.name.value==""){
      alert("��������Ʒ����!");
      form.name.select();
	  return(false);
	  }
	 return(true);
  }
</script>
<body topmargin="0" leftmargin="0" bottommargin="0" class="scrollbar" onLoad="chkscreen()">
<table width="950" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="114"  align="center">
<a href="index.php"><img src="images/banner.jpg" border=0></a>
	</td>
      </tr>
    </table>
   <table width="950" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr bgcolor="#054175">
    <td height="30"  align="center"><a  href='index.php'>��վ��ҳ</a>
	</td><td height="30"  align="center"><a linkindex="19" href="gonggao.php">���Ź���</a>
	</td><td height="30"  align="center"><a linkindex="17" href="goods.php">��Ʒ�б�</a>
	</td><td height="30"  align="center"><a linkindex="18" href="paihang.php">��������</a>
	</td><td height="30"  align="center"><a linkindex="19" href="mychart.php">�ҵĹ��ﳵ</a>
	</td><td height="30"  align="center"><a linkindex="19" href="tejia.php">�ؼ���Ʒ</a>
	</td>
    <td height="30"  align="center"><a linkindex="19" href="pinglun_view.php">��Ʒ����</a>
	</td>
    <td height="30"  align="center"><a linkindex="19" href="aboutus.php">���ڽ��ǹ���</a>
	</td>
    <td height="30"  align="center"><a href="index.php">��¼</a> |
									<a href="reg.php">ע��</a>
	</td>
      </tr>
    </table>
<table height="20" border="0" align="center" cellpadding="0" cellspacing="0">
              <form name="form" method="post" action="search.php">
                <tr>
                  <td width="81" height="30" align="right">&nbsp;</td>
                  <td width="950" height="30" valign="middle"><div align="left" style="color:#000">&nbsp;<span>&nbsp;�������Ʒ���ƣ�</span>
                          <input type="text" name="name" size="25" class="inputcss" style="background-color:#e8f4ff " onMouseOver="this.style.backgroundColor='#ffffff'" onMouseOut="this.style.backgroundColor='#e8f4ff'">
                          <input type="hidden" name="jdcz" value="jdcz">
                          <input name="submit" type="submit" class="buttoncss" value="��������">

</div></td>
                </tr>
              </form>
</table>