<?php
 include("header.php");
 include("conn.php");
?>
<table width="950" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="559" valign="top" bgcolor="#FFFFFF"><table width="950" height="20" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td height="33" bgcolor="#054175">&nbsp;&nbsp;��Ʒ��ϸҳ</td>
        </tr>
      </table>
        <table width="950" border="1" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td>
              <table width="950" border="1" align="center" cellpadding="0" cellspacing="0">
                <?php
		     $sql=mysql_query("select * from goods where id=".$_GET[id]."",$conn);
			 $views=mysql_fetch_object($sql);
		   ?>
                <tr>
                  <td width="300" height="80" rowspan="4" align="center" valign="middle" bgcolor="#FFFFFF"><div align="center">

                      <a href="<?php echo $views->tupian;?>" target="_blank"><img src="<?php echo $views->tupian;?>" alt="�鿴��ͼ" width="300" height="300" border="0"></a>

                  </div></td>
                  <td width="92" height="20" align="left" bgcolor="#FFFFFF"><div align="center">��Ʒ���ƣ�</div></td>
                  <td width="134" bgcolor="#FFFFFF"><div align="left">&nbsp;<?php echo $views->mingcheng;?></div></td>

                </tr>
                <tr>
                  <td height="20" align="left" bgcolor="#FFFFFF"><div align="center">��Ա�ۣ�</div></td>
                  <td width="134" bgcolor="#FFFFFF"><div align="left">&nbsp;<?php echo $views->huiyuanjia;?>Ԫ</div></td>

                </tr>
  <tr>
				  <td width="100" bgcolor="#FFFFFF"><div align="center">�г��ۣ�</div></td>
                  <td width="129" bgcolor="#FFFFFF"><div align="left">&nbsp;<?php echo $views->shichangjia;?>Ԫ</div></td>  </tr>
                <tr>

                  <td width="100" bgcolor="#FFFFFF"><div align="center">Ʒ�ƣ�</div></td>
                  <td width="129" bgcolor="#FFFFFF"><div align="left">&nbsp;<?php echo $views->pinpai;?></div></td>
                </tr>

                <tr>
                  <td width="89" height="80" bgcolor="#FFFFFF"><div align="center">��Ʒ��飺</div></td>
                  <td height="80" colspan="4" bgcolor="#FFFFFF" valign="top"><div align="left"><br>
&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $views->jianjie;?></div></td>
                </tr>
            </table></td>
          </tr>
      </table>
        <table width="530" height="20" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td><div align="right"><a href="shopping.php?id=<?php echo $views->id;?>">���ڹ���</a>&nbsp;&nbsp;</div></td>
          </tr>
      </table>
        <?php
	   if($_SESSION[username]!="")
	   {

	  ?>
<form name="form1" method="post" action="savepj.php?id=<?php echo $views->id;?>" onSubmit="return chkinput(this)">
<table width="530" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td height="25" bgcolor="#E7F3FB"><div align="center" >
                <div align="left">&nbsp;&nbsp;<span style="color: #006699">��������</span></div>
              </div></td>
            </tr>
            <tr>
              <td height="150" bgcolor="#999999"><table width="530" border="0" align="center" cellpadding="0" cellspacing="1">
                  <script language="javascript">
		    function chkinput(form)
			{
			   if(form.title.value=="")
			   {
			     alert("��������������!");
				 form.title.select();
				 return(false);
			   }
			   if(form.content.value=="")
			   {
			     alert("��������������!");
				 form.content.select();
				 return(false);
			   }
			   return(true);
			}
		  </script>
                  <tr>
                    <td width="80" height="25" bgcolor="#FFFFFF"><div align="center">�������⣺</div></td>
                    <td width="467" bgcolor="#FFFFFF"><div align="left">
                        <input type="text" name="title" size="30" class="inputcss" style="background-color:#e8f4ff " onMouseOver="this.style.backgroundColor='#ffffff'" onMouseOut="this.style.backgroundColor='#e8f4ff'">
                    </div></td>
                  </tr>
                  <tr>
                    <td height="125" bgcolor="#FFFFFF"><div align="center">�������ݣ�</div></td>
                    <td height="125" bgcolor="#FFFFFF"><div align="left">
                        <textarea name="content" cols="70" rows="10" class="inputcss" style="background-color:#e8f4ff " onMouseOver="this.style.backgroundColor='#ffffff'" onMouseOut="this.style.backgroundColor='#e8f4ff'"></textarea>
                    </div></td>
                  </tr>
              </table></td>
            </tr>
        </table>
          <table width="530" height="33" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td><div align="center">
                  <input type="submit" value="����" class="buttoncss">
&nbsp;&nbsp;&nbsp;<a href="pinglun_view.php?id=<?php echo $_GET[id];?>">�鿴����Ʒ����</a></div></td>
            </tr>
          </table>
      </form>
    <?php
	   }

	  ?>    </td>

  </tr>
</table>
<?php
 include("footer.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
