<style type="text/css">
<!--
.style1 {
	color: #FFCC00;
	font-size: 14px;
}
-->
</style>
   <table width="250" border="1" cellspacing="0" cellpadding="0">
        <tr>
          <td height="150" ><table width="250" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td height="25" colspan="3" bgcolor="#054175"><font color="#FFFFFF" size=+1>&nbsp;&nbsp;�û����</font></td>
            </tr>
            <tr>
              <td width="180"><table width="180" height="10" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td valign="top"><table width="100%" height="100" border="0" align="center" cellpadding="0" cellspacing="1">
                      <tr>
                        <td><table width="180" height="100" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td><table width="240" border="0" cellpadding="0" cellspacing="0">
                           <script language="javascript">
							 function chkuserinput(form){
							   if(form.username.value==""){
								  alert("�������û���!");
								  form.username.select();
								  return(false);
								}
								if(form.userpwd.value==""){
								  alert("�������û�����!");
								  form.userpwd.select();
								  return(false);
								}
								if(form.yz.value==""){
								  alert("��������֤��!");
								  form.yz.select();
								  return(false);
								}
							   return(true);
							 }
						  </script>
                                 <?php
								 if($_SESSION[username]=="")
								 {
								 ?>

								  <form name="form2" method="post" action="chkuser.php" onSubmit="return chkuserinput(this)">
                                    <tr>
                                      <td height="10" colspan="3">&nbsp;</td>
                                    </tr>
                                    <tr>
                                      <td width="80" height="20"><div align="right">�û���</div></td>
                                      <td height="20" colspan="2"><div align="left">
                                          <input type="text" name="username" size="19" class="inputcss" style="background-color:#e8f4ff " onMouseOver="this.style.backgroundColor='#ffffff'" onMouseOut="this.style.backgroundColor='#e8f4ff'">
                                      </div></td>
                                    </tr>
                                    <tr>
                                      <td height="20"><div align="right">���룺</div></td>
                                      <td colspan="2"><div align="left">
                                          <input type="password" name="userpwd" size="19" class="inputcss" style="background-color:#e8f4ff " onMouseOver="this.style.backgroundColor='#ffffff'" onMouseOut="this.style.backgroundColor='#e8f4ff'">
                                      </div></td>
                                    </tr>
                                    <tr>
                                      <td height="20"><div align="right">��֤��</div></td>
                                      <td width="66" height="20"><div align="left">
                                          <input type="text" name="yz" size="10" class="inputcss" style="background-color:#e8f4ff " onMouseOver="this.style.backgroundColor='#ffffff'" onMouseOut="this.style.backgroundColor='#e8f4ff'">
                                      </div></td>
                                      <td width="64"><div align="left"> &nbsp;
                                              <?php
									   $num=intval(mt_rand(1000,9999));
									   for($i=0;$i<4;$i++){
										echo "<img src=images/code/".substr(strval($num),$i,1).".gif>";
									   }
									?>
                                      </div></td>
                                    </tr>
                                    <tr>
                                      <td height="20" colspan="3">                                        <div align="right">
                                          <input type="hidden" value="<?php echo $num;?>" name="num">
                                          <input name="submit" type="submit" class="buttoncss" value="�� ��">
<a href="reg.php">ע��</a>&nbsp;</div></td>
                                    </tr>
                                  </form>
								  <?php
								 }else
										echo"<p align=center>��ӭ����:$_SESSION[username] <br>
									<a href=user.php>�û�����</a>
									<a href=logout.php>�˳���¼</a></p>";
								  ?>
                              </table></td>
                            </tr>
                        </table></td>
                      </tr>
                  </table></td>
                </tr>
              </table></td>
              <td width="17">&nbsp;</td>
            </tr>

          </table></td>
        </tr>

        <tr>
          <td width="240" height="25" bgcolor="#054175"><font color="#FFFFFF" size=+1>&nbsp;&nbsp;��վ����</font></td>
        </tr>
        <tr>
          <td height="40" ><table width="180"  border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td><table width="180"  border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td height="5"></td>
                  </tr>
                  <?php
								 $sql=mysql_query("select * from gonggao order by time desc limit 0,5",$conn);
								 $info=mysql_fetch_array($sql);
								 if($info==false){
				  ?>
                  <tr>
                    <td height="20" align="center">��վ���޹���!</td>
                  </tr>
                  <?php
								 }
								 else{
								   do{
				  ?>
                  <tr>
                    <td height="20"><div align="center">
                      <table width="180"  border="0" align="center" cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="16" height="5"><div align="center"><img src="images/xing.gif" width="9" height="9"></div></td>
                          <td width="164" height="24"><div align="left"> <a href="showgg.php?id=<?php echo $info[id];?>">
                              <?php
								 echo substr($info[title],0,24);
								  if(strlen($info[title])>24){
									echo "...";
								  }
							   ?>
                          </a> </div></td>
                        </tr>
                      </table>
                      </div></td>
                  </tr>
                  <?php
									 }
								   while($info=mysql_fetch_array($sql));
								 }
								?>
              </table></td>
            </tr>
          </table></td>
        </tr>


      </table>
      <p>&nbsp;</p>