<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<table width="950" border="1" align="center" cellpadding="0" cellspacing="0">

  <tr>
    <td height="81" bgcolor="#FFFFFF"><table width="552" height="47" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="42" height="81">&nbsp;</td>
        <td width="510" align="center"><table width="500" border="0" cellspacing="0" cellpadding="0">

          <tr>
            <td align="center"> ��Ȩ����</td>
          </tr>
 <tr>
            <td align="center"><a href="admin/">����Ա��¼</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>

</table>
</body>
</html>
