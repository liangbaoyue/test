<?php
require("header.php");
?>
<TABLE cellSpacing=0 cellPadding=0 width=960 align=center border=0>
  <TBODY>

  <TR>
    <TD width=200  align=left vAlign=top bgColor=#ffffff class=b>
<?php
require("login_box.php");
require("index_left.php");
?>
    </TD>
		                      <TD width=750 align=left vAlign=top class=b>
		                        <table width="750" border="0" cellpadding="0" cellspacing="0">
		    		<td height="167">


<table width=750 border=0 align="center" cellpadding=0 cellspacing=0>
 <tr>
    <td width="750" height="34" class="menu_bar">�Ƽ���Ʒ</td>
  </tr>
  <tr>
  <td>
	 <div id=demo style=overflow:hidden;height:200;width:750;color:#ffffff><table align=left cellpadding=0 cellspace=0 border=0>
	 <tr><td id=demo1 valign=top>
		<table border=0 cellpadding=0 cellspacing=0>
		<tr>
                  <td>
<?php
$sql="select * from goods where tuijian=1 order by id DESC limit 0,6";
$res=mysql_query($sql);
while($data=mysql_fetch_array($res))
{

?>
    <a href="good_view.php?id=<?php echo $data[id]?>"><img src="<?php echo $data[tupian]?>"  width="200" height="200"   style="border:1px solid #E9F9D5;"></a>&nbsp;

        <?php
}
		?></td>
		        </tr>
		</table>
	</td><td id=demo2 valign=top></td></tr></table></div>
  <script>
  var speed=10//�ٶ���ֵԽ���ٶ�Խ��
  demo2.innerHTML=demo1.innerHTML
  function Marquee(){
  if(demo2.offsetWidth-demo.scrollLeft<=0)
  demo.scrollLeft-=demo1.offsetWidth
  else{
  demo.scrollLeft++
  }
  }
  var MyMar=setInterval(Marquee,speed)
  demo.onmouseover=function() {clearInterval(MyMar)}
  demo.onmouseout=function() {MyMar=setInterval(Marquee,speed)}
  </script>
	</td></tr>
	</table>
<!--��ҳ����Ʒ��Ʒ-->

<table width=750 border="0" cellspacing="0" cellpadding="0" align="center">
 <tr>
    <td width="750" height="34" class="menu_bar">��Ʒ����</td>
  </tr></table>
  <table width=750 border="0" cellspacing="0" cellpadding="0" align="center">

  <tr>


        <tr>
        <?php
$sql="select * from goods order by id DESC limit 0,4";
$res=mysql_query($sql);
while($data=mysql_fetch_array($res))
{

?>
          <td ><TABLE  border=0 align="center" cellPadding=2 cellSpacing=1 bgColor=#e1e1e1 onMouseOver="this.style.backgroundColor='#FF6600'" onMouseOut="this.style.backgroundColor=''">
            <TBODY>
              <TR>
                <TD bgColor=#ffffff align=center>

              <a href="good_view.php?id=<?php echo $data[id]?>"><img src="<?php echo $data[tupian]?>"  width="180" height="180"   style="border:1px solid #E9F9D5;"></a>

                  </TD>
                </TR>
                <TR>
                <TD width=180 bgColor=#ffffff align=center>
             <a href="good_view.php?id=<?php echo $data[id]?>"><?php echo $data[mingcheng];?></a>
             <br>�г���:<font size=+1 color="#FF0000"><?php echo $data[shichangjia];?> </font>��Ա�ۣ�<font size=+1 color="blue"><?php echo $data[huiyuanjia];?></font><br><a href="shopping.php?id=<?php echo $data[id];?>">���빺�ﳵ</a>

                  </TD>
                </TR>
              </TBODY>

      </table></td>
      <?php
	  }
	  ?>
</tr>
</table>
</td>
		</table>

<table width="750" border="0" cellspacing="0" cellpadding="0" align="center">
 <tr>
    <td width="750" height="34" class="menu_bar">��������</td>
  </tr></table>
  <table width="750" border="0" cellspacing="0" cellpadding="0" align="center">

     <tr>
        <?php
$sql="select * from goods order by id DESC limit 0,4";
$res=mysql_query($sql);
while($data=mysql_fetch_array($res))
{

?>
          <td ><TABLE  border=0 align="center" cellPadding=2 cellSpacing=1 bgColor=#e1e1e1 onMouseOver="this.style.backgroundColor='#FF6600'" onMouseOut="this.style.backgroundColor=''">
            <TBODY>
              <TR>
                <TD bgColor=#ffffff align=center>

              <a href="good_view.php?id=<?php echo $data[id]?>"><img src="<?php echo $data[tupian]?>"  width="180" height="180"   style="border:1px solid #E9F9D5;"></a>

                  </TD>
                </TR>
                <TR>
                <TD width=180 bgColor=#ffffff align=center>

                <a href="good_view.php?id=<?php echo $data[id]?>"><?php echo $data[mingcheng];?></a>
             <br>�г���:<font size=+1 color="#FF0000"><?php echo $data[shichangjia];?> </font>��Ա�ۣ�<font size=+1 color="blue"><?php echo $data[huiyuanjia];?></font><br><a href="shopping.php?id=<?php echo $data[id];?>">���빺�ﳵ</a>

                  </TD>
                </TR>
              </TBODY>

      </table></td>
      <?php
	  }
	  ?>
  </table><td width="1" background="image/bgbg.gif"></td></table> </TD>
    </TR>
  </TBODY>
</TABLE>


<TABLE cellSpacing=0 cellPadding=0 width="960" align=center border=0>
  <TBODY>
    <TR>
      <td width="1" background="image/bgbg.gif"></td>
      <TD class=b vAlign=top align=left width=770><table width="770" align="center" border="0" cellspacing="0" cellpadding="0" >
        <tr>
          <td width="1" background="image/bgbg.gif"></td>
        </tr>
        <tr>
          <td height="24" align="center" valign="middle"><span class="style1"><span class="style2">&#21512;&#20316;&#20249;&#20276;</span> : </span><?php
$sql="select * from links order by id DESC limit 0,4";
$res=mysql_query($sql);
while($data=mysql_fetch_array($res))
{

?>
             | <a href=<?php echo $data[linkurl];?>><?php echo $data[linkname];?></a>
			 
			 <?php
}
			 ?>
			 </td>
        </tr>
        <tr>
          <td width="1" background="image/bgbg.gif"></td>
        </tr>
      </table>
      <td width="1" background="image/bgbg.gif"></td>
    </TR>
  </TBODY>
</TABLE>
<?php
require("footer.php");
?>
</body>
</html>