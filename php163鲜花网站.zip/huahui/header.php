<?php
error_reporting(E_ALL ^ E_NOTICE);

   session_start();
   include("conn.php");
?>
<html><head><title>��������ϵͳ</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link href="images/css.css" rel="stylesheet" type="text/css">
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" >

<style type="text/css">
<!--
body {
	background-image: url();
}
.style12 {color: #FF6633}
.style8 {font-size: 13px}
-->
</style>
<body bgcolor="#FFFFFF">

<DIV align=center>
  <TABLE border=0 cellPadding=0 cellSpacing=0 height=90 id=table1 width="960" >
                        <TBODY>
                          <TR>
                            <TD  bgColor=#ffffff><img src="images/logo.jpg" width="960"></TD>

                          </TR>
                        </TBODY>
                      </TABLE>
   <TABLE border=0 cellPadding=0 cellSpacing=0  id=table1  width="960" align="center">

        <TR>
          <TD background=images/navbg.gif height=45 class="navbg" align="center" style="padding-top:15px"><A href="index.php">��վ��ҳ</A> &nbsp;&nbsp;  &nbsp;&nbsp; <A
      href="tejia.php" >�Ƽ���Ʒ</A> &nbsp;&nbsp; <A
      href="gonggao.php" >���Ź���</A> &nbsp;&nbsp; <A href="reg.php">��Աע��</A> &nbsp;&nbsp; <A href="user.php">��Ա����</A> &nbsp;&nbsp; <A
      href="pinglun.php">��Ʒ����</A>&nbsp;&nbsp; <A
      href="finddd.php">������ѯ</A> &nbsp;&nbsp; <A       href="paihang.php" >��������</A> &nbsp;&nbsp; <A href="mychart.php" >�ҵĹ��ﳵ</P></TD>
        </TR>
      </table>
<center>
  <script type="text/javascript">
		var swf_width=960;
		var swf_height=400;
		//-- ���� �Զ�����ʱ��(��)|������ɫ|���ֱ���ɫ|���ֱ���͸����|����������ɫ|��ǰ������ɫ|��ͨ����ɫ�� --
		var config='4|#ffffff|#000000|50|#ffffff|#A41215|#000000';
		var files='',links='', texts='';
		files+='|images/1.jpg|images/2.jpg|images/3.jpg';links+='|||';texts+='|||';
		files=files.substring(1);
		links=links.substring(1);
		texts=texts.substring(1);
		document.write('<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" width="'+ swf_width +'" height="'+ swf_height +'">');
		document.write('<param name="movie" value="images/focus.swf" />');
		document.write('<param name="quality" value="high" />');
		document.write('<param name="menu" value="false" />');
		document.write('<param name=wmode value="opaque" />');
		document.write('<param name="FlashVars" value="config='+config+'&bcastr_flie='+files+'&bcastr_link='+links+'&bcastr_title='+texts+'" />');
		document.write('<embed src="images/focus.swf" wmode="opaque" FlashVars="config='+config+'&bcastr_flie='+files+'&bcastr_link='+links+'&bcastr_title='+texts+'& menu="false" quality="high" width="'+ swf_width +'" height="'+ swf_height +'" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />');
		document.write('</object>');
		</script>
</center>

<table width="960" height="15" border="0" align="center" cellpadding="0" cellspacing="0">
   <tr><td> </td>
  </tr>
</table>
