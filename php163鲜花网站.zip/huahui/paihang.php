<?php
 include("header.php");
?>
<table width="950" height="438" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="438" valign="top" bgcolor="#FFFFFF"><table width="950" height="33" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td bgcolor="#054175">&nbsp;&nbsp;<font color="#FFFFFF" size="+1">��������</td>
      </tr>
    </table>
      <table width="700" height="10" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td background="images/line1.gif"></td>
        </tr>
      </table>
      <?php



	  ?>
      <table width="950" height="70" border="1" align="center" cellpadding="0" cellspacing="0">
        <?php
            $sql1=mysql_query("select * from goods order by cishu desc",$conn);
             while($paihang=mysql_fetch_array($sql1))
		     {
		  ?>
        <tr>
          <td width="93" height="20"><div align="center" style="color: #000000">��Ʒ���ƣ�</div></td>
          <td colspan="5"><div align="left"> <a href="good_view.php?id=<?php echo $paihang[id];?>"><?php echo $paihang[mingcheng];?></a></div></td>
        </tr>




        <?php
	    }

		?>
      </table>
   </td>

  </tr>
</table>
<?php
 include("footer.php");
?>