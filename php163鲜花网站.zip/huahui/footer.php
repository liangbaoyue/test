<TABLE cellSpacing=0 cellPadding=0 width="960" align="center" border=0>
  <TBODY>
    <TR>
      <td width="1" background="image/bgbg.gif"></td>
      <TD width="960" align="center" vAlign=top class=b><table width="100%" align="center" border="0" cellspacing="0" cellpadding="0"  bordercolor="#CCCCCC">

      <td align="center" >��<a href="admin/">����Ա��¼</a><br>Copyright &copy;2015  Inc. All Rights  Reserved.  ��Ȩ����<br>
      </td>
  </tr>
      </table>
 </TD>
     <td width="1" background="image/bgbg.gif"></td>
    </TR>
  </TBODY>
</TABLE>
