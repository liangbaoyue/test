<?php
 include("header.php");
?>
<table width="950" height="438" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="438" valign="top" bgcolor="#FFFFFF">    <div align="center"><img src="images/gwlc.gif" width="235" height="490" /></div></td>
    <td width="229" align="center" valign="top" background="images/index_bg.gif"><div align="center">
	  <?php include("right.php");?>
    </div></td>
  </tr>
</table>
<?php
 include("footer.php");
?>