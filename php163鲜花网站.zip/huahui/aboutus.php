<?php
 include("header.php");
?>
<table width="950" height="438" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="438" valign="top" bgcolor="#FFFFFF"><table width="700" height="43" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><div align="left">���ǹ����������</div></td>
      </tr>
    </table>
      <table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td height="147" valign="top"> <div align="left">
		  &nbsp;���ǹ����̵����</div></td>
        </tr>
      </table>
      <table width="700" height="40" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td><div align="left">��ϵ���ǹ���</div></td>
        </tr>
      </table>
      <table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td height="81"><div align="center">
		  <P>��ϵ��ʽ:0992-5555555<BR><BR><BR></P>
		  </div></td>
        </tr>
    </table></td>

  </tr>
</table>
<?php
 include("footer.php");
?>