<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gbk" />
<title> Administrator's Control Panel</title>
<link rel="stylesheet" href="images/admincp.css" type="text/css" media="all" />
</head>
<body><div id="append"></div>
<script type="text/javascript">
	function headermenu(ctrl) {
		ctrl.className = ctrl.className == 'otherson' ? 'othersoff' : 'otherson';
		var menu = document.getElementById('header_menu_body');
		if(!menu) {
			menu = document.createElement('div');
			menu.id = 'header_menu_body';
			menu.innerHTML = '<ul>' + document.getElementById('header_menu_menu').innerHTML + '</ul>';
			var obj = ctrl;
			var x = ctrl.offsetLeft;
			var y = ctrl.offsetTop;
			while((obj = obj.offsetParent) != null) {
				x += obj.offsetLeft;
				y += obj.offsetTop;
			}
			menu.style.left = x + 'px';
			menu.style.top = y + ctrl.offsetHeight + 'px';
			menu.className = 'togglemenu';
			menu.style.display = '';
			document.body.appendChild(menu);
		} else {
			menu.style.display = menu.style.display == 'none' ? '' : 'none';
		}
	}
</script>
<div class="container">
	<h3>��ӭ������̨����</h3>
	<ul class="memlist fixwidth">
		<li></li>
		<li></li>
		<li></li>
		<li></li>
	</ul>


	<h3>ϵͳ�������û���</h3>
	<ul class="memlist fixwidth">
		<li>
<li><em>����ϵͳ�� PHP:</em>WINNT / PHP v5.2.5</li>
		<li><em>����������:</em>Apache/2.2.6 (Win32) PHP/5.2.5</li>
		<li><em>MySQL �汾:</em>5.0.45-community-nt</li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
	</ul>


</div>


</body>
</html>