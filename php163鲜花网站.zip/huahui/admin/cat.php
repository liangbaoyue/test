<?php include("check_login.php"); ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>��Ʒ������</title>
<link rel="stylesheet" type="text/css" href="images/admincp.css">
<style type="text/css">
<!--
.style1 {
}
-->
</style>
</head>

<body topmargin="0" leftmargin="0" bottommargin="0">
<?php
include("../conn.php");
$sql=mysql_query("select * from type order by id desc",$conn);
$info=mysql_fetch_array($sql);
 if($info==false)
  {
    echo "��վ������Ʒ���!";
   }
  else
  {
?>
<div align="center">
  <table width="600" border="0" align="left" cellpadding="0" cellspacing="0">
   <form name="form1" method="post" action="deletelb.php">
    <tr>
      <td height="20" bgcolor="#E7F3FB"><div align="center" >��Ʒ������</div></td>
    </tr>
    <tr>
      <td height="20" bgcolor="#E7F3FB"><table width="600" border="0" align="center" cellpadding="0" cellspacing="1">
        <tr>
          <td width="300" height="20" bgcolor="#FFFFFF"><div align="center">�������</div></td>
          <td width="144" bgcolor="#FFFFFF"><div align="center">����</div></td>
        </tr>
		<?php
		  do
		  {
		?>
        <tr>
          <td height="20" bgcolor="#FFFFFF"><div align="center"><?php echo $info[typename];?></div></td>
          <td height="20" bgcolor="#FFFFFF"><div align="center"><a href="cat_edit.php?id=<?php echo $info[id]?>">�޸� <a onclick="return confirm('ȷ��Ҫɾ����');"  href="cat_del.php?id=<?php echo $info[id]?>">ɾ��</a></div></td>
        </tr>

		<?php
		 }
		 while($info=mysql_fetch_array($sql));
		?>

      </table></td>
    </tr>
	</form>
  </table>
</div>
<?php
 }
?>
</body>
</html>
